var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "208809",
        "ok": "208312",
        "ko": "497"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "30604"
    },
    "maxResponseTime": {
        "total": "54242",
        "ok": "54242",
        "ko": "41002"
    },
    "meanResponseTime": {
        "total": "89",
        "ok": "3",
        "ko": "36095"
    },
    "standardDeviation": {
        "total": "1774",
        "ok": "213",
        "ko": "2025"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "36216"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "37062"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "39361"
    },
    "percentiles4": {
        "total": "4",
        "ok": "3",
        "ko": "39738"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 208130,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 53,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 129,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 497,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "751.112",
        "ok": "749.324",
        "ko": "1.788"
    }
},
contents: {
"req_open-websocket-ae989": {
        type: "REQUEST",
        name: "Open websocket",
path: "Open websocket",
pathFormatted: "req_open-websocket-ae989",
stats: {
    "name": "Open websocket",
    "numberOfRequests": {
        "total": "2500",
        "ok": "2003",
        "ko": "497"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "30604"
    },
    "maxResponseTime": {
        "total": "54242",
        "ok": "54242",
        "ko": "41002"
    },
    "meanResponseTime": {
        "total": "7401",
        "ok": "281",
        "ko": "36095"
    },
    "standardDeviation": {
        "total": "14451",
        "ok": "2155",
        "ko": "2025"
    },
    "percentiles1": {
        "total": "24",
        "ok": "10",
        "ko": "36216"
    },
    "percentiles2": {
        "total": "1219",
        "ok": "61",
        "ko": "37062"
    },
    "percentiles3": {
        "total": "37066",
        "ok": "1475",
        "ko": "39361"
    },
    "percentiles4": {
        "total": "39394",
        "ok": "2731",
        "ko": "39738"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1821,
        "percentage": 73
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 53,
        "percentage": 2
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 129,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 497,
        "percentage": 20
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "8.993",
        "ok": "7.205",
        "ko": "1.788"
    }
}
    },"req_connect-via-sto-aa02d": {
        type: "REQUEST",
        name: "Connect via STOMP",
path: "Connect via STOMP",
pathFormatted: "req_connect-via-sto-aa02d",
stats: {
    "name": "Connect via STOMP",
    "numberOfRequests": {
        "total": "2003",
        "ok": "2003",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2003,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.205",
        "ok": "7.205",
        "ko": "-"
    }
}
    },"req_subscribe-b2691": {
        type: "REQUEST",
        name: "Subscribe",
path: "Subscribe",
pathFormatted: "req_subscribe-b2691",
stats: {
    "name": "Subscribe",
    "numberOfRequests": {
        "total": "2003",
        "ok": "2003",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2003,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.205",
        "ok": "7.205",
        "ko": "-"
    }
}
    },"req_send-message-747c6": {
        type: "REQUEST",
        name: "Send message",
path: "Send message",
pathFormatted: "req_send-message-747c6",
stats: {
    "name": "Send message",
    "numberOfRequests": {
        "total": "200300",
        "ok": "200300",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles2": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles3": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles4": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 200300,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "720.504",
        "ok": "720.504",
        "ko": "-"
    }
}
    },"req_close-ws-0b669": {
        type: "REQUEST",
        name: "Close WS",
path: "Close WS",
pathFormatted: "req_close-ws-0b669",
stats: {
    "name": "Close WS",
    "numberOfRequests": {
        "total": "2003",
        "ok": "2003",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "59",
        "ok": "59",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4",
        "ok": "4",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7",
        "ok": "7",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16",
        "ok": "16",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2003,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "7.205",
        "ok": "7.205",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
