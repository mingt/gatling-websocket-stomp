var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "5000",
        "ok": "5000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2881",
        "ok": "2881",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "617",
        "ok": "617",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3",
        "ok": "3",
        "ko": "-"
    },
    "percentiles2": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2049",
        "ok": "2049",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2614",
        "ok": "2614",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4414,
        "percentage": 88
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 175,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 411,
        "percentage": 8
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "40.323",
        "ok": "40.323",
        "ko": "-"
    }
},
contents: {
"req_open-websocket-ae989": {
        type: "REQUEST",
        name: "Open websocket",
path: "Open websocket",
pathFormatted: "req_open-websocket-ae989",
stats: {
    "name": "Open websocket",
    "numberOfRequests": {
        "total": "2500",
        "ok": "2500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2881",
        "ok": "2881",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "394",
        "ok": "394",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "800",
        "ok": "800",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles2": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2422",
        "ok": "2422",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2779",
        "ok": "2779",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2060,
        "percentage": 82
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 70,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 370,
        "percentage": 15
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "20.161",
        "ok": "20.161",
        "ko": "-"
    }
}
    },"req_close-ws-0b669": {
        type: "REQUEST",
        name: "Close WS",
path: "Close WS",
pathFormatted: "req_close-ws-0b669",
stats: {
    "name": "Close WS",
    "numberOfRequests": {
        "total": "2500",
        "ok": "2500",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1697",
        "ok": "1697",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "99",
        "ok": "99",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "281",
        "ok": "281",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles3": {
        "total": "865",
        "ok": "865",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1339",
        "ok": "1339",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2354,
        "percentage": 94
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 105,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 41,
        "percentage": 2
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "20.161",
        "ok": "20.161",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
